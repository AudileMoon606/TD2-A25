﻿#pragma region "Includes"//{
#define _CRT_SECURE_NO_WARNINGS // On permet d'utiliser les fonctions de copies de chaînes qui sont considérées non sécuritaires.

#include "structures.hpp"      // Structures de données pour la collection de groupes musicaux en mémoire.

#include <iostream>
#include <fstream>
#include <string>
#include <limits>
#include <algorithm>
#include <span>

#include "cppitertools/range.hpp"

#include "bibliotheque_cours.hpp"
#include "verification_allocation.hpp" // Nos fonctions pour le rapport de fuites de mémoire.
#include "debogage_memoire.hpp"        // Ajout des numéros de ligne des "new" dans le rapport de fuites.  Doit être après les include du système, qui peuvent utiliser des "placement new" (non supporté par notre ajout de numéros de lignes).

using namespace std;
using namespace iter;

#pragma endregion//}

typedef uint8_t UInt8;
typedef uint16_t UInt16;

#pragma region "Fonctions de base pour lire le fichier binaire"//{

UInt8 lireUint8(istream& fichier)
{
	UInt8 valeur = 0;
	fichier.read((char*)&valeur, sizeof(valeur));
	return valeur;
}
UInt16 lireUint16(istream& fichier)
{
	UInt16 valeur = 0;
	fichier.read((char*)&valeur, sizeof(valeur));
	return valeur;
}
string lireString(istream& fichier)
{
	string texte;
	texte.resize(lireUint16(fichier));
	fichier.read((char*)&texte[0], streamsize(sizeof(texte[0])) * texte.length());
	return texte;
}

#pragma endregion//}

//TODO: Une fonction pour ajouter un Groupe à une ListeGroupes, le groupe existant déjà; on veut uniquement ajouter le pointeur vers le groupe existant.  Cette fonction doit doubler la taille du tableau alloué, avec au minimum un élément, dans le cas où la capacité est insuffisante pour ajouter l'élément.  Il faut alors allouer un nouveau tableau plus grand, copier ce qu'il y avait dans l'ancien, et éliminer l'ancien trop petit.  Cette fonction ne doit copier aucun Groupe ni Musicien, elle doit copier uniquement des pointeurs.
void ajouterAuGroupe(ListeGroupes& liste, Groupe* g) {
	if (liste.nElements >= liste.capacite) {
		int nouvelleCapacite = max(1, liste.capacite * 2);
		Groupe** nouv = new Groupe * [nouvelleCapacite];
		for (int i = 0; i < liste.nElements; i++)
			nouv[i] = liste.elements[i];
		delete[] liste.elements;
		liste.elements = nouv;
		liste.capacite = nouvelleCapacite;
	}
	liste.elements[liste.nElements++] = g;
}



//TODO: Une fonction pour enlever un Groupe d'une ListeGroupes (enlever le pointeur) sans effacer le groupe; la fonction prenant en paramètre un pointeur vers le groupe à enlever.  L'ordre des groupes dans la liste n'a pas à être conservé.
void enleverUnGroupe(ListeGroupes& liste, Groupe* g) {
	for (int i = 0; i < liste.nElements; i++) {
		if (liste.elements[i] == g) {
			liste.elements[i] = liste.elements[liste.nElements - 1]; // pas besoin de conserver l'ordre
			liste.nElements--;
			break;
		}
	}

//TODO: Une fonction pour trouver un Musicien par son nom dans une ListeGroupes, qui retourne un pointeur vers le musicien, ou nullptr si le musicien n'est pas trouvé.  Devrait utiliser span.
	Musicien* trouverMusicien(const ListeGroupes & liste, const string & nom) {
		std::span<Groupe* const> groupes(liste.elements, liste.nElements); // span sur les groupes
		for (Groupe* g : groupes) {
			std::span<Musicien* const> membres(g->membres.elements, g->membres.nElements); 
			for (Musicien* m : membres) {
				if (m->nom == nom)
					return m;
			}
		}
		return nullptr;  // comme une mis
	}

//TODO: Compléter les fonctions pour lire le fichier et créer/allouer une ListeGroupes.  La ListeGroupes devra être passée entre les fonctions, pour vérifier l'existence d'un Musicien avant de l'allouer à nouveau (cherché par nom en utilisant la fonction ci-dessus).
Musicien* lireMusicien(istream& fichier)
{
	Musicien musicien = {};
	musicien.nom            = lireString(fichier);
	musicien.pays           = lireString(fichier);
	musicien.anneeNaissance = lireUint16(fichier);
	// Vérifier si le musicien existe déjà
	Musicien* existant = trouverMusicien(listeGroupes, musicien.nom);
	if (existant != nullptr) return existant;
		
	
	// Sinon, créer un nouveau musicien
	Musicien* nouveau = new Musicien(musicien);
	nouveau->joueDans.elements = nullptr;
	nouveau->joueDans.nElements = 0;
	nouveau->joueDans.capacite = 0;

	cout << "Création d'une musicien: " << nouveau->nom; // Debug

	return nouveau; // Retourner le pointeur vers le nouveau musicien; //TODO: Retourner un pointeur soit vers un musicien existant ou un nouveau musicien ayant les bonnes informations, selon si le musicien existait déjà.  Pour fins de débogage, affichez les noms des membres crées; vous ne devriez pas voir le même nom de musicien affiché deux fois pour la création.
}

Groupe* lireGroupe(istream& fichier)
{
	Groupe groupe = {};
	groupe.nom   = lireString(fichier);
	groupe.genre = lireString(fichier);
	groupe.anneeFormation = lireUint16 (fichier);
	groupe.membres.nElements = lireUint8 (fichier);  //NOTE: Vous avez le droit d'allouer d'un coup le tableau pour les membres, sans faire de réallocation comme pour ListeGroupes.  Vous pouvez aussi copier-coller les fonctions d'allocation de ListeGroupes ci-dessus dans des nouvelles fonctions et faire un remplacement de Groupe par Musicien, pour réutiliser cette réallocation.
	cout << groupe.nom << endl;
	for (int i = 0; i < groupe.membres.nElements; i++) {
		// Récupérer le musicien (nouveau ou existant)
		Musicien* m = lireMusicien(fichier);  // retourne le pointeur vers le musicien

		// Placer le musicien dans le groupe
		groupe.membres.elements[i] = m;

		// Ajouter le groupe à la liste des groupes dans lesquels le musicien joue
		if (m->joueDans.capacite == 0) {
			m->joueDans.capacite = 1;
			m->joueDans.elements = new Groupe * [1];
		}
		else if (m->joueDans.nElements == m->joueDans.capacite) {
			int newCap = m->joueDans.capacite * 2;
			Groupe** tmp = new Groupe * [newCap];
			for (int j = 0; j < m->joueDans.nElements; j++)
				tmp[j] = m->joueDans.elements[j];
			delete[] m->joueDans.elements;
			m->joueDans.elements = tmp;
			m->joueDans.capacite = newCap;
		}
		m->joueDans.elements[m->joueDans.nElements++] = &groupe;
	}

	// Retourner le pointeur vers le nouveau groupe
	Groupe* nouveauGroupe = new Groupe(groupe);
	return nouveauGroupe; //TODO: Retourner le pointeur vers le nouveau groupe.
}





ListeGroupes creerListe(string nomFichier)
{
	ifstream fichier(nomFichier, ios::binary);
	fichier.exceptions(ios::failbit);

	int nElements = lireUint16(fichier);

	//TODO: Créer une liste de groupes vide.
	ListeGroupes liste = {};
	liste.capacite = (nElements > 0) ? nElements : 1;
	liste.nElements = 0;
	liste.elements = new Groupe * [liste.capacite];

	for (int i = 0; i < nElements; i++) {
		// Lire le groupe
		Groupe* g = lireGroupe(fichier);

		//TODO: Ajouter le groupe à la liste.
		if (liste.nElements == liste.capacite) {
			int newCap = (liste.capacite == 0) ? 1 : liste.capacite * 2;
			Groupe** tmp = new Groupe * [newCap];
			for (int j = 0; j < liste.nElements; j++)
				tmp[j] = liste.elements[j];
			delete[] liste.elements;
			liste.elements = tmp;
			liste.capacite = newCap;
		}
		liste.elements[liste.nElements++] = g;
	}

	//TODO: Retourner la liste de groupes.
	return liste;
}

//TODO: Une fonction pour détruire un groupe
void detruireGroupe(Groupe* g) {
	for (int i = 0; i < g->membres.nElements; i++) {
		Musicien* m = g->membres.elements[i];
		for (int j = 0; j < m->joueDans.nElements; j++) {
			if (m->joueDans.elements[j] == g) {
				m->joueDans.elements[j] = m->joueDans.elements[m->joueDans.nElements - 1];
				m->joueDans.nElements--;
				break;
			}
		}
		if (m->joueDans.nElements == 0) {
			cout << "Destruction de: " << m->nom << endl;
			delete[] m->joueDans.elements;
			delete m;
		}
	}
	delete[] g->membres.elements;
	delete g;
}

//TODO: Une fonction pour détruire une ListeGroupes et tous les groupes qu'ellle contient
void detruireListeGroupes(ListeGroupes& liste) {
	for (int i = 0; i < liste.nElements; i++) {
		detruireGroupe(liste.elements[i]);
	}
	delete[] liste.elements;
	liste.nElements = 0;
	liste.capacite = 0;
}

void afficherMusicien(const Musicien& musicien)
{
	cout << "  " << musicien.nom << ", " << musicien.pays << ", " << musicien.anneeNaissance << endl;
}

//TODO: Une fonction pour afficher un groupe avec tous ses membres (en utilisant la fonction afficherMusicien ci-dessus).
void afficherGroupe(const Groupe& groupe)
{
	cout << groupe.nom << " (" << groupe.genre << ", " << groupe.anneeFormation << ")" << endl;
	for (int i = 0; i < groupe.membres.nElements; i++)
		afficherMusicien(*groupe.membres.elements[i]);
}


void afficherListeGroupes(const ListeGroupes& listeGroupes)
{
	//TODO: Utiliser des caractères Unicode pour définir la ligne de séparation (différente des autres lignes de séparations dans ce progamme).
	static const string ligneDeSeparation = "\n\033[36m──────────────────────────────\033[0m\n";
	cout << ligneDeSeparation;
	//TODO: Changer le for pour utiliser un span.
	for (auto g : span(listeGroupes.elements, listeGroupes.nElements)) {
		//TODO: Afficher le groupe.
		afficherGroupe(*g);
		cout << ligneDeSeparation;
	}
}

void afficherGroupesMusicien(const ListeGroupes& listeGroupes, const string& nomMusicien)
{
	//TODO: Utiliser votre fonction pour trouver le musicien (au lieu de le mettre à nullptr).
	const Musicien* musicien = trouverMusicien(listeGroupes, nomMusicien);;
	if (musicien == nullptr)
		cout << "Aucun musicien de ce nom" << endl;
	else
		afficherListeGroupes(musicien->joueDans);
}

int main()
{
	bibliotheque_cours::activerCouleursAnsi();  // Permet sous Windows les "ANSI escape code" pour changer de couleurs https://en.wikipedia.org/wiki/ANSI_escape_code ; les consoles Linux/Mac les supportent normalement par défaut.

	int* fuite = new int; //TODO: Enlever cette ligne après avoir vérifié qu'il y a bien un "Fuite detectee" de "4 octets" affiché à la fin de l'exécution, qui réfère à cette ligne du programme.

	static const string ligneDeSeparation = "\n\033[35m════════════════════════════════════════\033[0m\n";

	//TODO: Chaque TODO dans cette fonction devrait se faire en 1 ou 2 lignes, en appelant les fonctions écrites.

	//TODO: La ligne suivante devrait lire le fichier binaire en allouant la mémoire nécessaire.  Devrait afficher les noms des 22 musiciens sans doublons (par l'affichage pour fins de débogage dans votre fonction lireMusicien).
	ListeGroupes listeGroupes = creerListe("groupes.bin");

	cout << ligneDeSeparation << "Le premier groupe de la liste est:" << endl;
	//TODO: Afficher le premier groupe de la liste.  Devrait être Nirvana.
	if (listeGroupes.nElements > 0)
		afficherGroupe(*listeGroupes.elements[0]);

	cout << ligneDeSeparation << "Les groupes sont:" << endl;
	//TODO: Afficher la liste des groupes.  Il devrait y en avoir 7.
	afficherListeGroupes(listeGroupes);

	//TODO: Modifier le pays de Dave Grohl pour être États-Unis (est vide dans les données lues du fichier).  Vous ne pouvez pas supposer l'ordre des groupes et des membres dans les listes, il faut y aller par son nom.
	if (Musicien* dg = trouverMusicien(listeGroupes, "Dave Grohl"))
		dg->pays = "États-Unis";

	cout << ligneDeSeparation << "Liste des groupes où Dave Grohl joue sont:" << endl;
	//TODO: Afficher la liste des groupe où Dave Grohl joue.  Il devrait y avoir Nirvana et Foo Fighters.
	afficherGroupesMusicien(listeGroupes, "Dave Grohl");

	//TODO: Détruire et enlever le premier groupe de la liste (Nirvana).  Ceci devrait "automatiquement" (par ce que font vos fonctions) détruire les membres Kurt Cobain et Krist Novoselic, mais pas Dave Grohl puisqu'il joue aussi dans Foo Fighters.
	if (listeGroupes.nElements > 0)
		detruireGroupe(listeGroupes.elements[0], listeGroupes);

	cout << ligneDeSeparation << "Les groupes sont maintenant:" << endl;
	//TODO: Afficher la liste des groupes.
	afficherListeGroupes(listeGroupes);

	//TODO: Faire les appels qui manquent pour avoir 0% de lignes non exécutées dans le programme (aucune ligne rouge dans la couverture de code; c'est normal que les lignes de "new" et "delete" soient jaunes).  Vous avez aussi le droit d'effacer les lignes du programmes qui ne sont pas exécutée, si finalement vous pensez qu'elle ne sont pas utiles.

	//TODO: Détruire tout avant de terminer le programme.  La bibliothèque de verification_allocation devrait afficher "Aucune fuite detectee." a la sortie du programme; il affichera "Fuite detectee:" avec la liste des blocs, s'il manque des delete.
	detruireListeGroupes(listeGroupes);
}

}
